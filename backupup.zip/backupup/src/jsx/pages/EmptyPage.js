import React from 'react'

export const EmptyPage = () => {
  return (
    <div>EmptyPage</div>
  )
}
