import React from 'react';
import { Modal, Button, Container, Row, Col } from 'react-bootstrap';

const InventoryEditModal = ({ show, handleClose }) => {
  return (
    <Modal className="fade" show={show} onHide={handleClose}>
      <form>
        <Modal.Header>
          <Modal.Title><i class="fas fa-edit"></i>Edit Inventory Deatils!!!</Modal.Title>
          <Button variant="" className="btn-close" onClick={handleClose}></Button>
        </Modal.Header>
        <Modal.Body>
          <Container>
            <Row>
              <Col md="6">
                <label>Name</label>
                <input type="text" className="form-control form-control-sm" />
              </Col>
              <Col md="6">
                <label>Email</label>
                <input type="text" className="form-control form-control-sm" />
              </Col>
            </Row>
          </Container>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="danger light" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary">Save changes</Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default InventoryEditModal;
