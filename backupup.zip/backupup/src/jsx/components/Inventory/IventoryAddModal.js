import React, { useState, useEffect } from 'react';
import { Modal, Button, Container, Row, Col } from 'react-bootstrap';
import ProductServices from '../../../services/ProductServices';

const InventoryAddModal = ({ show, handleClose, item }) => {
  const user = JSON.parse(localStorage.getItem('userDetails'));
  const store = user?.data?.user?.store;
  
  const [formValues, setFormValues] = useState({
    partNo: '',
    category: '',
    description: '',
    unit: '',
    qtyAuth: '',
    criticalStockQty: '',
    store: store ? store[0]._id : '', // select the first store by default
    remark: '',
  });

  const [previewImage, setPreviewImage] = useState('');

  // Update form values when item changes
  useEffect(() => {
    if (item) {
      setFormValues({
        partNo: item?.partNo || '',
        category: item?.category?.name || '',
        description: item?.description || '',
        unit: item?.unit?.name || '',
        qtyAuth: '',
        criticalStockQty: '',
        store: store ? store[0]._id : '',
        remark: '',
      });

      setPreviewImage(item?.image 
        ? `http://localhost:3001/img/product/${item.image}` 
        : 'img/placeholder-img.png');
    }
  }, [item]);

  // Handle input changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  // Submit form
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await ProductServices.AddInventory({
        "masterItem": item._id,
        "qtyAuth": formValues.qtyAuth,
        "criticalStockQty": formValues.criticalStockQty,
        "store": formValues.store,
        "remark": formValues.remark,
      });
      alert('Inventory Added Successfully');
      handleClose();
    } catch (error) {
      alert(error.response.data.message)
    }
  };

  return (
    <Modal className="fade" show={show} onHide={handleClose} size='lg'>
      <form onSubmit={handleSubmit}>
        <Modal.Header>
          <Modal.Title>
            <i className="fa fa-plus me-2" aria-hidden="true"></i>
            Inventory Details
          </Modal.Title>
          <Button variant="" className="btn-close" onClick={handleClose}></Button>
        </Modal.Header>
        <Modal.Body>
          <Container>
            <Row>
              <Col md="4">
                <label>Part No</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  name="partNo"
                  value={formValues.partNo}
                  readOnly
                />
              </Col>
              <Col md="4">
                <label>Category</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  name="category"
                  value={formValues.category}
                  readOnly
                />
              </Col>
              <Col md="4">
                <label>Description</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  name="description"
                  value={formValues.description}
                  readOnly
                />
              </Col>
              <Col md="4">
                <label>Unit</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  name="unit"
                  value={formValues.unit}
                  readOnly
                />
              </Col>
              <Col md="4">
                <label>Qty Auth</label>
                <input
                  type="number"
                  className="form-control form-control-sm"
                  name="qtyAuth"
                  value={formValues.qtyAuth}
                  onChange={handleInputChange}
                />
              </Col>
              <Col md="4">
                <label>Critical Stock Qty</label>
                <input
                  type="number"
                  className="form-control form-control-sm"
                  name="criticalStockQty"
                  value={formValues.criticalStockQty}
                  onChange={handleInputChange}
                />
              </Col>
              <Col md="4">
                <label>Store Location</label>
                <select
                  className="form-select"
                  name="store"
                  value={formValues.store}
                  onChange={handleInputChange}
                >
                  {store?.map((s, index) => (
                    <option key={index} value={s._id}>
                      {`${s.name}, ${s.location}`}
                    </option>
                  ))}
                </select>
              </Col>
              <Col md="4">
                <label>Remark</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  name="remark"
                  value={formValues.remark}
                  onChange={handleInputChange}
                />
              </Col>
              <Col md="12" className="mt-3 text-center">
                <img src={previewImage} alt="Item Preview" width="200" />
              </Col>
            </Row>
          </Container>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="danger light" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type="submit">Save changes</Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default InventoryAddModal;
