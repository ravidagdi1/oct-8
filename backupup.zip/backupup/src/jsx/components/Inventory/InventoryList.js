import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import Collapse from "react-bootstrap/Collapse";
import Select from "react-select";
import ProductServices from "../../../services/ProductServices";

const InventoryList = () => {
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Retrieve user and stores from localStorage
  const user = JSON.parse(localStorage.getItem('userDetails'));
  const availableStores = user?.data?.user?.store || [];
  const defaultStore = availableStores[0]?._id || '';

  const [stores, setStores] = useState(availableStores);
  const [selectedStore, setSelectedStore] = useState(defaultStore);
  const [searchTerm, setSearchTerm] = useState('');
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [sort, setsort] = useState(10); // Number of items per page
  const activePag = useRef(0);
  const [test, setTest] = useState(0);

  // Display row options
  const options = [
    { value: 5, label: "5" },
    { value: 10, label: "10" },
    { value: 20, label: "20" },
    { value: 50, label: "50" },
    { value: 100, label: "100" },
  ];

  // Function to change the displayed data based on pagination
  const changeData = (first, second) => {
    const domData = Array.from(
      document.querySelectorAll("#transactions-data tbody tr")
    );
    domData.forEach((row, index) => {
      if (index >= first && index < second) {
        row.classList.remove("d-none");
      } else {
        row.classList.add("d-none");
      }
    });
  };

  // Fetch data from API and filter based on selectedStore
  useEffect(() => {
    if (selectedStore) {
      setLoading(true);
      ProductServices.getInventory()
        .then((response) => {
          const allData = response?.data?.data || [];
          // Filter the data based on the selected store
          const storeFilteredData = allData.filter(
            (item) => item?.store?._id === selectedStore
          );
          setData(storeFilteredData);
          setLoading(false);
        })
        .catch((error) => {
          alert("There is some problem in fetching data!");
          setLoading(false);
        });
    }
  }, [selectedStore, test]);

  // Handle search
  useEffect(() => {
    if (searchTerm) {
      const filtered = data.filter((item) =>
        item?.masterItem?.partNo?.toString()?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item?.masterItem?.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item?.masterItem?.category?.name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredData(filtered);
    } else {
      setFilteredData(data);
    }
  }, [searchTerm, data]);

  // Pagination setup
  useEffect(() => {
    if (filteredData.length > 0) {
      changeData(activePag.current * sort, (activePag.current + 1) * sort);
    }
  }, [filteredData, sort]);

  const pagination = Math.ceil(filteredData.length / sort);

  const onClick = (i) => {
    activePag.current = i;
    changeData(activePag.current * sort, (activePag.current + 1) * sort);
    setTest(i);
  };

  const handleSelectChange = (selectedOption) => {
    setsort(selectedOption.value);
    activePag.current = 0;
  };

  const handleStoreChange = (e) => {
    setSelectedStore(e.target.value);
    activePag.current = 0; // Reset pagination when store changes
  };

  const Persentage = (user) => {
    const a = user?.requestedQty || 0;  // Requested quantity
    const b = user?.receiveQty || 0;    // Received quantity
    
    if (a === 0 || b === 0) {
      return 0; // Prevent division by zero
    }
  
    const c = (b / a) * 100; // Correct percentage calculation
    const roundedPercentage = c.toFixed(2); // Round to 2 decimal places
  
    return isNaN(roundedPercentage) ? 0 : roundedPercentage;
  };

  return (
    <>
      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open ? "collapse" : "expand"}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    
                    <div className="col-xl-3 col-xxl-6">
                      <input
                        type="text"
                        className="form-control mb-xl-0 mb-3"
                        id="searchInput"
                        placeholder="Search"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="col-xl-3 col-xxl-3">
                      
                      <select
                        className="form-select mb-xl-0 mb-3"
                        value={selectedStore}
                        onChange={handleStoreChange}
                      >
                        {stores.map((store) => (
                          <option key={store._id} value={store._id}>
                            {store.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="col-xl-3 col-xxl-3">
                      <Select
                        placeholder="Select Display Rows"
                        value={options.find((option) => option.value === sort)}
                        onChange={handleSelectChange}
                        isSearchable={false}
                        options={options}
                        className="custom-react-select mb-3 mb-xxl-0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
          <div className="mb-3">
            <ul className="d-flex align-items-center flex-wrap">
              <li>
                <Link to={"#"} className="btn btn-primary ">
                  Generate New Requisition No
                </Link>
              </li>
              <li>
                <Link to={"#"} className="btn btn-primary mx-1">
                  Generate New MIV No
                </Link>
              </li>
              <li>
                <Link
                  to={"#"}
                  className="btn btn-primary mt-sm-0 mt-1"
                >
                  Generate Requisition No
                </Link>
              </li>
            </ul>
          </div>
          <div className="filter cm-content-box box-primary mt-5">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-file-word me-2"></i>Inventory List
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div
                      id="content_wrapper"
                      className="dataTables_wrapper no-footer"
                    >
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="transactions-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Part No.</th>
                            <th>Image</th>
                            <th>L/P</th>
                            <th>Auth Qty</th>
                            <th>Received Qty</th>
                            <th>Transfer Qty</th>
                            <th>MIV Qty</th>
                            <th>Critical Status</th>
                            <th>Current Stock</th>
                            <th>Received %</th>
                            <th className="text-center">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.isArray(filteredData) && filteredData.length > 0 ? (
                            filteredData.map((item, index) => (
                              <tr key={index}>
                                <td>{activePag.current * sort + index + 1}</td>
                                <td>{item?.masterItem?.partNo}</td>
                                <td>
                                  {item?.masterItem?.image ? (
                                    <img
                                      src={`http://localhost:3001/img/product/${item?.masterItem?.image}`}
                                      alt={item?.masterItem?.partNo}
                                      className="thumbnail-image"
                                    />
                                  ) : (
                                    "No image available"
                                  )}
                                </td>
                                <td>{item?.lp}</td>
                                <td>{item?.qtyAuth}</td>
                                <td>{item?.totalReceive}</td>
                                <td>{item?.transfer}</td>
                                <td>{item?.Miv}</td>                               
                                <td>{item?.currentStock <= item?.criticalStockQty ?  `${item?.criticalStockQty} Low` : item?.criticalStockQty }</td>
                                <td>{item?.currentStock}</td>
                                <td>{Persentage(item)}%</td>
                                <td>
                                  <button
                                    className="btn btn-warning btn-sm content-icon me-1"
                                   
                                  >
                                    <i className="fa fa-edit"></i>
                                  </button>
                                  <Link
                                    to={"#"}
                                    className="btn btn-danger btn-sm content-icon ms-1"
                                  >
                                    <i className="fa fa-times"></i>
                                  </Link>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="12">No data available</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(
                            filteredData.length,
                            (activePag.current + 1) * sort
                          )}{" "}
                          of {filteredData.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="#"
                            onClick={() =>
                              activePag.current > 0 &&
                              onClick(activePag.current - 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-left"
                              aria-hidden="true"
                            ></i>
                          </Link>
                          <span>
                            {Array.from({ length: pagination }, (_, i) => (
                              <Link
                                key={i}
                                to="#"
                                className={`paginate_button ${
                                  activePag.current === i ? "current" : ""
                                }`}
                                onClick={() => onClick(i)}
                              >
                                {i + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="#"
                            onClick={() =>
                              activePag.current + 1 < pagination &&
                              onClick(activePag.current + 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-right"
                              aria-hidden="true"
                            ></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default InventoryList;
