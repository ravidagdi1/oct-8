import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { Tab, Nav } from "react-bootstrap";
import Collapse from "react-bootstrap/Collapse";
import LocationServices from "../../../services/LocationServices";
import Swal from "sweetalert2";
import LocationEditModal from './LocationEditModal'


const InactiveLocation = () => {
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [gridInsideModal, setGridInsideModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState([]);
  const sort = 2; // Number of items per page
  const activePag = useRef(0);
  const [test, setTest] = useState(0);
  const [run, setRun] = useState()
  // Function to change the displayed data based on pagination
  const changeData = (first, second) => {
    const domData = Array.from(
      document.querySelectorAll("#inactive-locations-data tbody tr")
    );
    domData.forEach((row, index) => {
      if (index >= first && index < second) {
        row.classList.remove("d-none");
      } else {
        row.classList.add("d-none");
      }
    });
  };

  // Fetch data from API
  useEffect(() => {
    setLoading(true);
    LocationServices.getStore()
      .then((res) => {
        const filteredInactiveStores = res.data.data.filter(
          (store) => store.status === "inactive"
        );
        setData(filteredInactiveStores);
        setLoading(false);
      })
      .catch((error) => {
        setError("There was a problem fetching the data!");
        setLoading(false);
      });
  }, [run]);

  // Pagination setup
  useEffect(() => {
    if (data.length > 0) {
      changeData(activePag.current * sort, (activePag.current + 1) * sort);
    }
  }, [data]);

  const pagination = Math.ceil(data.length / sort); // Calculate number of pages

  const onClick = (i) => {
    activePag.current = i;
    changeData(activePag.current * sort, (activePag.current + 1) * sort);
    setTest(i);
  };

  function handleDelete(e) {
    Swal.fire({
      title: 'Are you sure to delete ?',
      text: "You will not be able to recover this User Again !!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dd6b55',
      cancelButtonColor: '#aaa',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire(
          'Deleted!',
          'User has been deleted.',
          'success'
        )
      }
    })


  }

  return (
    <>

      <LocationEditModal
        show={gridInsideModal}
        handleClose={() => setGridInsideModal(false)}
      />
      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link to={"#"} className={`SlideToolHeader ${open ? 'collapse' : 'expand'}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    <div className="col-xl-3 col-xxl-6">
                      <input type="text" className="form-control mb-xl-0 mb-3" id="exampleFormControlInput1" placeholder="Title" />
                    </div>


                    <div className="col-xl- col-xxl-6">
                      <button className="btn btn-primary me-2" title="Click here to Search" type="button"><i className="fa fa-search me-1"></i>Filter</button>
                    </div>
                  </div>

                </div>
              </div>
            </Collapse>
          </div>
          <div className="filter cm-content-box box-primary mt-5">
            <div className={`content-title`}>
              <div className="cpa">
              <i class="fa fa-list me-2" aria-hidden="true"></i>Inactive Stores
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"
                    }`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div
                      id="content_wrapper"
                      className="dataTables_wrapper no-footer"
                    >
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="inactive-locations-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Store Name</th>
                            <th>Location</th>
                            <th className="text-end">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.isArray(data) && data.length > 0 ? (
                            data.map((item, index) => (
                              <tr key={index}>
                                <td>
                                  {activePag.current * sort + index + 1}
                                </td>
                                <td>{item?.name}</td>
                                <td>{item?.location}</td>
                                <td className="text-end">
                                  <button className="btn btn-warning btn-sm content-icon me-1" onClick={() => setGridInsideModal(true)}>
                                    <i className="fa fa-edit"></i>
                                  </button>
                                  <button className="btn btn-danger btn-sm content-icon ms-1" onClick={(e) => { handleDelete(e) }}>
                                    <i className="fa fa-times"></i>
                                  </button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="5">No inactive stores</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(
                            data.length,
                            (activePag.current + 1) * sort
                          )}{" "}
                          of {data.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="#"
                            onClick={() =>
                              activePag.current > 0 &&
                              onClick(activePag.current - 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-left"
                              aria-hidden="true"
                            ></i>
                          </Link>
                          <span>
                            {Array.from(
                              { length: pagination },
                              (_, i) => (
                                <Link
                                  key={i}
                                  to="#"
                                  className={`paginate_button ${activePag.current === i
                                      ? "current"
                                      : ""
                                    }`}
                                  onClick={() => onClick(i)}
                                >
                                  {i + 1}
                                </Link>
                              )
                            )}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="#"
                            onClick={() =>
                              activePag.current + 1 < pagination &&
                              onClick(activePag.current + 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-right"
                              aria-hidden="true"
                            ></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>


    </>
  );
};

export default InactiveLocation;
