import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import Collapse from "react-bootstrap/Collapse";
import UserServices from "../../../services/UserServices";
import Swal from "sweetalert2";
import UseEditModal from './UseEditModal';
import Select from 'react-select';

const UserPending = () => {
  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(true);
  const [gridInsideModal, setGridInsideModal] = useState(false);
  const [sort, setsort] = useState(5); // Number of items per page
  const activePag = useRef(0);
  const [test, setTest] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [pendingUsers, setPendingUsers] = useState([]);
  const [activePage, setActivePag] = useState();

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await UserServices.getAllUser();
      const allUsers = response?.data?.data || [];
      const filteredPendingUsers = allUsers.filter(
        (user) => user.status === "inactive"
      );
      setPendingUsers(filteredPendingUsers);
    };

    fetchUsers();
  }, [test]);

  // Search code
  const filteredSearch = pendingUsers.filter(user =>
    user?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user?.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user?.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Options for row selections
  const options = [
    { value: '5', label: '5' },
    { value: '10', label: '10' },
    { value: '20', label: '20' },
    { value: '50', label: '50' },
    { value: '100', label: '100' }
  ];

  // Pagination setup
  useEffect(() => {
    if (pendingUsers.length > 0) {
      setActivePag(0); // Reset pagination when data changes
    }
  }, [pendingUsers]);

  // Calculate total pages
  const pagination = Math.ceil(pendingUsers.length / sort);

  // Handle page click
  const onClick = (i) => {
    activePag.current = i;
    setTest(i);
  };

  // Handle deleting user
  function handleDelete(e, user) {
    Swal.fire({
      title: 'Are you sure to delete?',
      text: "You will not be able to recover this User Again!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dd6b55',
      cancelButtonColor: '#aaa',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        UserServices.deleteUser(user._id).then(() => {
          setTest(user._id);
          Swal.fire('Deleted!', 'User has been deleted.', 'success');
        }).catch((error) => {
          console.log(error);
          Swal.fire('Error!', 'There was a problem deleting the user.', 'error');
        });
      }
    });
  }

  // Handle status toggle for inactive users
  const handleStatusToggle = async (user) => {
    const newStatus = user.status === "inactive" ? "active" : "inactive";
    const updatedUser = { ...user, status: newStatus }; // Create updated user object

    try {
      await UserServices.updateUser(user._id, updatedUser); // Use the updateUser service
      setTest(prev => prev + 1); // Trigger re-fetch or re-render
      Swal.fire('Success!', `User status updated to ${newStatus}.`, 'success');
    } catch (error) {
      console.error(error);
      Swal.fire('Error!', 'There was a problem updating the user status.', 'error');
    }
  };

  return (
    <>
      <UseEditModal
        show={gridInsideModal}
        handleClose={() => setGridInsideModal(false)}
      />

      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link to={"#"} className={`SlideToolHeader ${open ? 'collapse' : 'expand'}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    <div className="col-xl-3 col-xxl-6">
                      <input type="text"
                        className="form-control mb-xl-0 mb-3"
                        id="exampleFormControlInput1"
                        placeholder="Search"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="col-xl-3 col-xxl-6">
                      <Select
                        placeholder="Select row to display in User Table"
                        value={options.find(option => option.value === sort)} // set the current selected value
                        onChange={(selectedOption) => setsort(selectedOption.value)} // update `sort` on selection
                        isSearchable={false}
                        options={options}
                        className="custom-react-select mb-3 mb-xxl-0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
          <div className="filter cm-content-box box-primary mt-1">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fa fa-list me-2" aria-hidden="true"></i>Pending User <span className="badge bg-orange ms-2">{filteredSearch.length}</span>
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div id="content_wrapper" className="dataTables_wrapper no-footer">
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="pending-users-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>User Role</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Store</th>
                            <th>Status</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredSearch.length > 0 ? (
                            filteredSearch
                              .slice(activePag.current * sort, (activePag.current + 1) * sort)
                              .map((user, index) => (
                                <tr key={index}>
                                  <td>{activePag.current * sort + index + 1}</td>
                                  <td>{user?.role}</td>
                                  <td>{user?.name}</td>
                                  <td>{user?.email}</td>
                                  <td>{user?.store[0]?.name}</td>
                                  <td>
                                    <span 
                                      onClick={() => handleStatusToggle(user)} 
                                      style={{ cursor: 'pointer' }}
                                    >
                                      <i 
                                        className={`fa ${user.status === 'inactive' ? 'fa-circle text-danger' : 'fa-circle text-success'}`}
                                        title={user.status === 'inactive' ? 'Inactive' : 'Active'}
                                      ></i>
                                    </span>
                                  </td>
                                  <td className="text-center">
                                    <button className="btn btn-primary btn-xs sharp" onClick={() => setGridInsideModal(true)}>
                                      <i className="fa fa-pencil"></i>
                                    </button>
                                    <button className="btn btn-danger btn-xs sharp" onClick={(e) => { handleDelete(e, user) }}>
                                      <i className="fa fa-trash"></i>
                                    </button>
                                  </td>
                                </tr>
                              ))
                          ) : (
                            <tr>
                              <td colSpan="7" className="text-center">No Pending Users Found</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(pendingUsers.length, (activePag.current + 1) * sort)}{" "}
                          of {pendingUsers.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="#"
                            onClick={() =>
                              activePag.current > 0 && onClick(activePag.current - 1)
                            }
                          >
                            <i className="fa fa-angle-double-left" aria-hidden="true"></i>
                          </Link>
                          <span>
                            {Array.from({ length: pagination }, (_, i) => (
                              <Link
                                key={i}
                                to="#"
                                className={`paginate_button ${activePag.current === i ? "current" : ""}`}
                                onClick={() => onClick(i)}
                              >
                                {i + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="#"
                            onClick={() =>
                              activePag.current + 1 < pagination && onClick(activePag.current + 1)
                            }
                          >
                            <i className="fa fa-angle-double-right" aria-hidden="true"></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserPending;
