import React, { useState } from "react";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import Collapse from "react-bootstrap/Collapse";
import useAsync from "../../../hooks/useAsync";
import LocationServices from "../../../services/LocationServices";
import AdminServices from "../../../services/AdminServices";

const UserAdd = () => {
  const [open2, setOpen2] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [selectedRole, setSelectedRole] = useState("");
  const [stores, setSelectedStores] = useState([]); // Changed to array for multiple stores
  const [error, setError] = useState("");

  // Fetch stores for the store location dropdown
  const { data, error: fetchError, isLoading } = useAsync(LocationServices.getStore);

  // Handle store selection (multiple stores)
  const handleStoreChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    setSelectedStores(selectedOptions);
  };

  const isValidEmail = (email) => {
    // Basic email validation regex pattern
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check for empty fields
    if (!name || !email || !password || !confirmPassword || !selectedRole || stores.length === 0) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "All fields are required!",
      });
      return;
    }

    // Check if email is valid
    if (!isValidEmail(email)) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Please enter a valid email address!",
      });
      return;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Passwords do not match!",
      });
      return;
    }

    try {
      const newUser = {
        name,
        email,
        password,
        role: selectedRole,
        stores,  // Send the array of selected stores
        passwordConfirm: confirmPassword,
      };

      const response = await AdminServices.signUp(newUser);

      if (response.status === "success") {
        Swal.fire({
          icon: "success",
          title: "Good job!",
          text: "User Added Successfully!",
        });
        // Reset form fields
        setName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
        setSelectedRole("");
        setSelectedStores([]);  // Clear selected stores
        setError("");
      } else {
        setError("Failed to add user");
      }
    } catch (error) {
      setError(error.response?.data?.message || "An error occurred");
    }
  };

  return (
    <>
      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary mt-1">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fa fa-user-plus me-2" aria-hidden="true"></i>Add User
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div id="content_wrapper" className="dataTables_wrapper no-footer">
                      <form onSubmit={handleSubmit}>
                        <div className="row">
                          <div className="form-group mb-3 col-md-6">
                            <label>Full Name</label>
                            <input
                              type="text"
                              className="form-control"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                              placeholder="Full Name"
                            />
                          </div>
                          <div className="form-group mb-3 col-md-6">
                            <label>Email</label>
                            <input
                              type="email"
                              className="form-control"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              placeholder="Email"
                            />
                          </div>
                          <div className="form-group mb-3 col-md-6">
                            <label>Password</label>
                            <input
                              type="password"
                              className="form-control"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              placeholder="Password"
                            />
                          </div>
                          <div className="form-group mb-3 col-md-6">
                            <label>Confirm Password</label>
                            <input
                              type="password"
                              className="form-control"
                              value={confirmPassword}
                              onChange={(e) => setConfirmPassword(e.target.value)}
                              placeholder="Confirm Password"
                            />
                          </div>
                        </div>

                        <div className="row">
                          <div className="form-group mb-3 col-md-6">
                            <label>Assign Role</label>
                            <select
                              className="form-control"
                              value={selectedRole}
                              onChange={(e) => setSelectedRole(e.target.value)}
                            >
                              <option value="">Choose...</option>
                              <option value="admin">Admin</option>
                              <option value="storeKeeper">Store Keeper</option>
                            </select>
                          </div>

                          {/* Multi-select for Stores */}
                          <div className="form-group mb-3 col-md-6">
                            <label>Location</label>
                            <select
                              className="form-control"
                              multiple
                              value={stores}
                              onChange={handleStoreChange}
                            >
                              <option value="">Select Store</option>
                              {data?.data?.data?.map((store, index) => (
                                <option key={index} value={store._id}>
                                  {`${store.name}, ${store.location}`}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        {/* Error Message */}
                        {error && <p style={{ color: "red" }}>{error}</p>}

                        <button type="submit" className="btn btn-primary me-2">
                          Submit
                        </button>
                        <button
                          type="button"
                          className="btn btn-danger"
                          onClick={() => {
                            // Reset fields
                            setName("");
                            setEmail("");
                            setPassword("");
                            setConfirmPassword("");
                            setSelectedRole("");
                            setSelectedStores([]); // Clear selected stores
                            setError("");
                          }}
                        >
                          Cancel
                        </button>
                      </form>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3"></div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserAdd;
