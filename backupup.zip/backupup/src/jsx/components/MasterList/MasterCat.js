import React, { useState, useEffect, useReducer } from 'react';
import { Collapse } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import CategoryServices from '../../../services/CategoryServices';
import useAsync from "../../../hooks/useAsync";
import Swal from "sweetalert2";

const initialState = {
    openCollapse1: true,
    openCollapse2: true,
};

const reducer = (state, action) => {
    switch (action.type) {
        case 'openCollapse1':
            return { ...state, openCollapse1: !state.openCollapse1 };
        case 'openCollapse2':
            return { ...state, openCollapse2: !state.openCollapse2 };
        default:
            return state;
    }
};

const MasterCat = () => {
    const [state, dispatch] = useReducer(reducer, initialState);
    const [categories, setCategories] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [formValues, setFormValues] = useState({ name: '' });
    const [run, setRun] = useState(0)

    // Fetch categories from the API
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await CategoryServices.getCategory();
                setCategories(response.data.data);
            } catch (error) {
                console.error('Error fetching categories', error);
            }
        };
        fetchCategories();
    }, []);

    // Handle form input changes
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormValues({
            ...formValues,
            [name]: value,
        });
    };

    // Add new category
    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            if (formValues.name === '') {
                //alert('Please fill in all fields');
                Swal.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: 'Please Fill Category!',                        
                  })
            } else {
                const res = await CategoryServices.createCategory({ name: formValues.name });
                if (res.status === 'success') {
                    //alert('Category added successfully');
                    Swal.fire({
                        icon: 'success',
                        title: 'Good job!',
                        text: "Category Added successfully!",                        
                      })
                    setFormValues({ name: '' });
                    setCategories([...categories, res.data.data]);
                } else {
                    alert('Something went wrong');
                    
                }
            }
        } catch (error) {
            console.error('Failed to add category', error);
            alert('Failed to add category');
        }
    };

    // Search filtering

    // Delete function

    const handledelete=async(e,id)=>{
        alert(id)
        const res = await CategoryServices.deleteCategory(id);
        console.log(res)
         
    }
    
     // Filter Category based on the search name
     const filteredUnits = categories.filter(unit =>
        unit.name.toLowerCase().includes(searchTerm.toLowerCase())
    );


    return (
        <>
            <div className="row">
                <div className="col-xl-12">
                    <div className="row page-titles">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link to={"#"}>Master-List</Link></li>
                            <li className="breadcrumb-item"><Link to={"#"}>Add Category</Link></li>
                            <li className="breadcrumb-item active">List</li>
                        </ol>
                    </div>
                    <div className="row">
                        {/* Add Category */}
                        <div className="col-xl-4">
                            <div className="filter cm-content-box box-primary">
                                <div className="content-title">
                                    <div className="cpa">
                                        <i className="fa-solid fa-file-lines me-1"></i>Add Category
                                    </div>
                                    <div className="tools">
                                        <Link to={"#"}
                                            className={`SlideToolHeader ${state.openCollapse1 ? 'collapse' : 'expand'}`}
                                            onClick={() => dispatch({ type: 'openCollapse1' })}
                                        >
                                            <i className="fas fa-angle-up" />
                                        </Link>
                                    </div>
                                </div>
                                <Collapse in={state.openCollapse1}>
                                    <div className="cm-content-body form excerpt">
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="mb-3">
                                                    <label className="form-label">Category Name</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        name="name"
                                                        value={formValues.name}
                                                        onChange={handleInputChange}
                                                        placeholder="Name"
                                                    />
                                                </div>
                                                <button type="submit" className="btn btn-primary">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                </Collapse>
                            </div>
                        </div>

                        {/* Category List */}
                        <div className="col-xl-8">
                            <div className="filter cm-content-box box-primary">
                                <div className="content-title">
                                    <div className="cpa">
                                        <i className="fa-solid fa-file-lines me-1"></i>Category List
                                    </div>
                                    <div className="tools">
                                        <Link to={"#"}
                                            className={`SlideToolHeader ${state.openCollapse2 ? 'collapse' : 'expand'}`}
                                            onClick={() => dispatch({ type: 'openCollapse2' })}
                                        >
                                            <i className="fas fa-angle-up" />
                                        </Link>
                                    </div>
                                </div>
                                <Collapse in={state.openCollapse2}>
                                    <div className="cm-content-body publish-content form excerpt">
                                        <div className="card-body">
                                            <input
                                                type="text"
                                                className="form-control mb-3"
                                                placeholder="Search category"
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                            />
                                            <div className="table-responsive">
                                                <table className="table table-bordered table-striped verticle-middle table-responsive-sm">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">#</th>
                                                            <th scope="col">Category ID</th>
                                                            <th scope="col">Category Name</th>
                                                            <th scope="col">Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {filteredUnits?.length >0?(
                                                            filteredUnits.map((category, index) => (
                                                            <tr key={category._id}>
                                                                <td>{index + 1}</td>
                                                                <td>{category._id}</td>
                                                                <td>{category.name}</td>
                                                                <td>

                                                                <button className="btn btn-danger btn-xs sharp" onClick={(e) => { handledelete(e,category._id) }}>
                                                                            <i className="fa fa-trash"></i>
                                                                        </button>

                                                                </td>
                                                            </tr>
                                                         ))
                                                        ) : (
                                                            <tr>
                                                                <td colSpan="4">No Record Found</td>
                                                            </tr>
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </Collapse>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </>
    );
};

export default MasterCat;
