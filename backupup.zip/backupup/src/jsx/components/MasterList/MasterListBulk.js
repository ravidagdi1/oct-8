import { useState } from "react";
import PageTItle from "../../layouts/PageTitle";
import axios from "axios";
import ProductServices from "../../../services/ProductServices";

const MasterListBulk = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.type === "application/vnd.ms-excel")) {
      setSelectedFile(file);
      setErrorMessage("");
    } else {
      setErrorMessage("Please upload a valid Excel file.");
      setSelectedFile(null);
    }
  };

  const handleFileUpload = async () => {
    if (!selectedFile) {
      setErrorMessage("Please select a file before uploading.");
      return;
    }

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const response = await ProductServices.bulkUpload(formData) 
      console.log("File uploaded successfully", response.data);
    } catch (error) {
      // Handle error response here
      console.log("File upload failed", error);
    }
  };

  return (
    <>
      <PageTItle activeMenu="Master List Bulk Upload" motherMenu="Master List" pageContent="User" />
      <div className="col-xl-12 col-lg-12">
        <div className="card">
          <div className="card-body">
            <div className="basic-form">
              <form onSubmit={(e) => e.preventDefault()}>
                <div className="row">
                  <div className="col-xl-6 col-lg-6">
                    <div className="input-group">
                      <div className="form-file">
                        <input
                          type="file"
                          className="form-file-input form-control"
                          onChange={handleFileChange}
                        />
                      </div>
                      <button
                        className="btn btn-primary btn-sm"
                        type="button"
                        onClick={handleFileUpload}
                      >
                        Upload
                      </button>
                    </div>
                    {errorMessage && (
                      <div className="text-danger mt-2">{errorMessage}</div>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default MasterListBulk;
