import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import Collapse from "react-bootstrap/Collapse";
import Select from "react-select";
import ProductServices from "../../../services/ProductServices";
import MasterListEdit from "./MasterListEdit";

const MasterList = () => {
  const [gridInsideModal, setGridInsideModal] = useState(false);
  const [open, setOpen] = useState(true);
  const [open2, setOpen2] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sort, setsort] = useState(10);
  const activePag = useRef(0);
  const [test, setTest] = useState(0);
  const [selectedItem, setSelectedItem] = useState();


  const options = [
    { value: 10, label: "10" },
    { value: 20, label: "20" },
    { value: 50, label: "50" },
    { value: 100, label: "100" },
  ];

  const changeData = (first, second) => {
    const domData = Array.from(
      document.querySelectorAll("#transactions-data tbody tr")
    );
    domData.forEach((row, index) => {
      if (index >= first && index < second) {
        row.classList.remove("d-none");
      } else {
        row.classList.add("d-none");
      }
    });
  };

  useEffect(() => {
    setLoading(true);
    try {
      ProductServices.getAllProduct()
        .then((response) => {
          setData(response?.data?.data || []);
        })
        .catch(() => {
          alert("There is some problem in fetching data!");
        });
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  }, [test]);

  const handleEditClick = (item) => {
    setSelectedItem(item); // Set the item to be edited
    setGridInsideModal(true); // Show modal
  };

  useEffect(() => {
    if (searchTerm) {
      const filtered = data.filter(
        (item) =>
          String(item?.partNo)
            ?.toLowerCase()
            .includes(searchTerm.toLowerCase()) ||
          item?.category?.name
            ?.toLowerCase()
            .includes(searchTerm.toLowerCase()) ||
          item?.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredData(filtered);
    } else {
      setFilteredData(data);
    }
  }, [searchTerm, data]);

  useEffect(() => {
    if (filteredData.length > 0) {
      changeData(activePag.current * sort, (activePag.current + 1) * sort);
    }
  }, [filteredData, sort]);

  const pagination = Math.ceil(filteredData.length / sort);

  const onClick = (i) => {
    activePag.current = i;
    changeData(activePag.current * sort, (activePag.current + 1) * sort);
    setTest(i);
  };

  const handleSelectChange = (selectedOption) => {
    setsort(selectedOption.value);
    activePag.current = 0;
  };

  return (
    <>
      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-filter me-2"></i>Filter
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open ? "collapse" : "expand"}`}
                  onClick={() => setOpen(!open)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="row">
                    <div className="col-xl-3 col-xxl-6">
                      <input
                        type="text"
                        className="form-control mb-xl-0 mb-3"
                        id="searchInput"
                        placeholder="Search by Part No., Category, or Description"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>

                    <div className="col-xl-3 col-xxl-6">
                      <Select
                        placeholder="Select rows to display in User Table"
                        value={options.find((option) => option.value === sort)}
                        onChange={handleSelectChange}
                        isSearchable={false}
                        options={options}
                        className="custom-react-select mb-3 mb-xxl-0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
          <div className="filter cm-content-box box-primary mt-5">
            <div className={`content-title`}>
              <div className="cpa">
                <i className="fas fa-file-word me-2"></i>Master List
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>
            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <div className="table-responsive">
                    <div
                      id="content_wrapper"
                      className="dataTables_wrapper no-footer"
                    >
                      <table
                        className="table table-bordered table-responsive-lg table-striped table-condensed flip-content"
                        id="transactions-data"
                      >
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Part No.</th>
                            <th>Image</th>
                            <th>Category</th>
                            <th>Unit</th>
                            <th>Description</th>
                            <th>Remark</th>
                            <th className="text-center">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.isArray(filteredData) &&
                          filteredData.length > 0 ? (
                            filteredData.map((item, index) => (
                              <tr key={index}>
                                <td>{activePag.current * sort + index + 1}</td>
                                <td>{item?.partNo}</td>
                                <td>
                                  {item.image ? (
                                    <img
                                      src={`http://localhost:3001/img/product/${item?.image}`}
                                      alt={item.partNo}
                                      className="thumbnail-image"
                                    />
                                  ) : (
                                    "No image available"
                                  )}
                                </td>
                                <td>{item?.category?.name}</td>
                                <td>{item?.unit?.name}</td>
                                <td>{item?.description}</td>
                                <td>{item?.remark}</td>
                                <td className="text-center">
                                  <button
                                    className="btn btn-primary btn-xs sharp"
                                    onClick={() => handleEditClick(item)} // Open modal on edit click
                                  >
                                     <i className="fa fa-pencil"></i>
                                  </button>
                                  <button className="btn btn-danger btn-xs sharp">
                                      <i className="fa fa-trash"></i>
                                    </button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="8" className="text-center">
                                No records found.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                      <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                        <div className="dataTables_info">
                          Showing {activePag.current * sort + 1} to{" "}
                          {Math.min(
                            data.length,
                            (activePag.current + 1) * sort
                          )}{" "}
                          of {data.length} entries
                        </div>
                        <div className="dataTables_paginate paging_simple_numbers">
                          <Link
                            className="paginate_button previous"
                            to="/master-list"
                            onClick={() =>
                              activePag.current > 0 &&
                              onClick(activePag.current - 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-left"
                              aria-hidden="true"
                            ></i>
                          </Link>
                          <span>
                            {Array.from({ length: pagination }, (_, i) => (
                              <Link
                                key={i}
                                to="/master-list"
                                className={`paginate_button ${
                                  activePag.current === i ? "current" : ""
                                }`}
                                onClick={() => onClick(i)}
                              >
                                {i + 1}
                              </Link>
                            ))}
                          </span>
                          <Link
                            className="paginate_button next"
                            to="/master-list"
                            onClick={() =>
                              activePag.current + 1 < pagination &&
                              onClick(activePag.current + 1)
                            }
                          >
                            <i
                              className="fa fa-angle-double-right"
                              aria-hidden="true"
                            ></i>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
      <MasterListEdit
        item={selectedItem}
        show={gridInsideModal}
        test= {setTest}
        handleClose={() => setGridInsideModal(false)}
      />
    </>
  );
};

export default MasterList;
