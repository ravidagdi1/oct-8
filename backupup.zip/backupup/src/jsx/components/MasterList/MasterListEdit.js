import React, { useState, useEffect } from 'react';
import { Modal, Button, Container, Row, Col } from 'react-bootstrap';
import ProductServices from '../../../services/ProductServices';

const MasterListEdit = ({ show, handleClose, test, item }) => {
  const [description, setDescription] = useState('');  // Initialize as empty
  const [image, setImage] = useState(null); // New image file
  const [previewImage, setPreviewImage] = useState('');

  // Update description and preview image when the item changes
  useEffect(() => {
    if (item) {
      setDescription(item.description || '');
      setPreviewImage(`http://localhost:3001/img/product/${item.image}` || '');
    }
  }, [item]);

  // Function to handle image change and preview
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result); // Update preview
      };
      reader.readAsDataURL(file);
      setImage(file); // Set new image file
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('description', description); // Append updated description
    if (image) {
      formData.append('photo', image); // Append updated image if changed
    }

    try {
      await ProductServices.updateProduct(item._id, formData);
      test((prev) => prev + 1); // Trigger re-render or update
      handleClose(); // Close modal after successful update
    } catch (error) {
      console.error('Error updating the item', error);
    }
  };

  return (
    <Modal className="fade" show={show} onHide={handleClose}>
      <form onSubmit={handleSubmit}>
        <Modal.Header>
          <Modal.Title><i className="fas fa-edit"></i> Edit Master Item</Modal.Title>
          <Button variant="" className="btn-close" onClick={handleClose}></Button>
        </Modal.Header>
        <Modal.Body>
          <Container>
            <Row>
              <Col md="6">
                <label>Part No.</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={item?.partNo || 'N/A'}
                  readOnly
                />
              </Col>
              <Col md="6">
                <label>Category</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={item?.category?.name || 'N/A'}
                  readOnly
                />
              </Col>
              <Col md="6">
                <label>Unit</label>
                <input
                  type="text"
                  className="form-control form-control-sm"
                  value={item?.unit?.name || 'N/A'}
                  readOnly
                />
              </Col>
              <Col md="12">
                <label>Description</label>
                <textarea
                  className="form-control"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </Col>
              <Col md="12" className="mt-3">
                <label>Current Image</label>
                <div className="file-preview text-center">
                  <img src={previewImage} alt="Preview" style={{ maxWidth: '200px' }} />
                </div>
                <label className="mt-2">Change Image</label>
                <input
                  type="file"
                  className="form-control form-control-sm"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </Col>
            </Row>
          </Container>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="danger light" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type="submit">
            Save Changes
          </Button>
        </Modal.Footer>
      </form>
    </Modal>
  );
};

export default MasterListEdit;
