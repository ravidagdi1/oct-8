import React, { useState, useEffect, useReducer } from 'react';
import Swal from "sweetalert2";
import { Collapse } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import CategoryServices from '../../../services/CategoryServices';

const initialState = {
    openCollapse1: true,
    openCollapse2: true,
};

const reducer = (state, action) => {
    switch (action.type) {
        case 'openCollapse1':
            return { ...state, openCollapse1: !state.openCollapse1 };
        case 'openCollapse2':
            return { ...state, openCollapse2: !state.openCollapse2 };
        default:
            return state;
    }
};

const MasterUnit = () => {
    const [state, dispatch] = useReducer(reducer, initialState);
    const [units, setUnits] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [formValues, setFormValues] = useState({ name: '' });

    // Fetch units from the API
    useEffect(() => {
        const fetchUnits = async () => {
            try {
                const response = await CategoryServices.getUnit();
                setUnits(response.data.data);
            } catch (error) {
                console.error('Error fetching units', error);
            }
        };
        fetchUnits();
    }, []);

    // Handle form input changes
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormValues({
            ...formValues,
            [name]: value,
        });
    };

    // Add new unit
    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            if (formValues.name === '') {
                //alert('Please fill in all fields');
                Swal.fire({
                    icon: 'error',
                    title: 'Oops',
                    text: 'Please Fill Unit filed!',                        
                  })
            } else {
                const res = await CategoryServices.createUnit({ name: formValues.name });
                if (res.status === 'success') {
                    //alert('Unit added successfully');
                    Swal.fire({
                        icon: 'success',
                        title: 'Good job!',
                        text: "Unit Added Successfully!",                        
                      })
                    setFormValues({ name: '' });
                    setUnits([...units, res.data.data]);
                } else {
                    alert('Something went wrong');
                }
            }
        } catch (error) {
            console.error('Failed to add unit', error);
            alert('Failed to add unit');
        }
    };

    // Filter units based on the search term
    const filteredUnits = units.filter(unit =>
        unit.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
// CatGeory Delete Function
    function handleDelete(e) {
        Swal.fire({
          title: 'Are you sure to delete ?',
          text: "You will not be able to recover this User Again !!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#dd6b55',
          cancelButtonColor: '#aaa',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            Swal.fire(
              'Deleted!',
              'User has been deleted.',
              'success'
            )
          }
        })
    
    
      }

    return (
        <>
            <div className="row">
                <div className="col-xl-12">
                    <div className="row page-titles">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link to={"#"}>Master-List</Link></li>
                            <li className="breadcrumb-item"><Link to={"#"}>Master Unit</Link></li>
                            <li className="breadcrumb-item active">List</li>
                        </ol>
                    </div>
                    <div className="row">
                        {/* Add Unit */}
                        <div className="col-xl-4">
                            <div className="filter cm-content-box box-primary">
                                <div className="content-title">
                                    <div className="cpa">
                                        <i className="fa-solid fa-file-lines me-1"></i>Add Unit
                                    </div>
                                    <div className="tools">
                                        <Link to={"#"}
                                            className={`SlideToolHeader ${state.openCollapse1 ? 'collapse' : 'expand'}`}
                                            onClick={() => dispatch({ type: 'openCollapse1' })}
                                        >
                                            <i className="fas fa-angle-up" />
                                        </Link>
                                    </div>
                                </div>
                                <Collapse in={state.openCollapse1}>
                                    <div className="cm-content-body form excerpt">
                                        <div className="card-body">
                                            <form onSubmit={handleSubmit}>
                                                <div className="mb-3">
                                                    <label className="form-label">Unit Name</label>
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        name="name"
                                                        value={formValues.name}
                                                        onChange={handleInputChange}
                                                        placeholder="Name"
                                                    />
                                                </div>
                                                <button type="submit" className="btn btn-primary">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                </Collapse>
                            </div>
                        </div>

                        {/* Unit List */}
                        <div className="col-xl-8">
                            <div className="filter cm-content-box box-primary">
                                <div className="content-title">
                                    <div className="cpa">
                                        <i className="fa-solid fa-file-lines me-1"></i>Unit List
                                    </div>
                                    <div className="tools">
                                        <Link to={"#"}
                                            className={`SlideToolHeader ${state.openCollapse2 ? 'collapse' : 'expand'}`}
                                            onClick={() => dispatch({ type: 'openCollapse2' })}
                                        >
                                            <i className="fas fa-angle-up" />
                                        </Link>
                                    </div>
                                </div>
                                <Collapse in={state.openCollapse2}>
                                    <div className="cm-content-body publish-content form excerpt">
                                        <div className="card-body">
                                            <input
                                                type="text"
                                                className="form-control mb-3"
                                                placeholder="Search unit"
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                            />
                                            <div className="table-responsive">
                                                <table className="table table-bordered table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">#</th>
                                                            <th scope="col">ID</th>
                                                            <th scope="col">Unit Name</th>
                                                            <th scope="col">Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {filteredUnits.length > 0 ? (
                                                            filteredUnits?.map((unit, index) => (
                                                                <tr key={unit._id}>
                                                                    <td>{index + 1}</td>
                                                                    <td>{unit._id}</td>
                                                                    <td>{unit.name}</td>
                                                                    <td>
                                                                        <button className="btn btn-danger btn-xs sharp" onClick={(e) => { handleDelete(e) }}>
                                                                            <i className="fa fa-trash"></i>
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            ))
                                                        ) : (
                                                            <tr>
                                                                <td colSpan="4">No Record Found</td>
                                                            </tr>
                                                        )}

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </Collapse>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default MasterUnit;
