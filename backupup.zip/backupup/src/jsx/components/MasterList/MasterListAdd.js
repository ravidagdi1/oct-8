import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Collapse from 'react-bootstrap/Collapse';
import Swal from 'sweetalert2';
import CategoryServices from '../../../services/CategoryServices';
import ProductServices from '../../../services/ProductServices';
const MasterListAdd = () => {
  const [open2, setOpen2] = useState(true);
  const [categories, setCategories] = useState([]);
  const [units, setUnits] = useState([]);
  const [previewImage, setPreviewImage] = useState('img/placeholder-img.png'); // Placeholder image
  const [formValues, setFormValues] = useState({
    partNo: '',
    category: '',
    description: '',
    unit: '',
    remark: '',
    photo: null,
  });

  // Handle input changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  // Handle file input change for image preview
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
      setFormValues({
        ...formValues,
        photo: file,
      });
    }
  };

  // Fetch categories and units from API
  useEffect(() => {
    const fetchCategoriesAndUnits = async () => {
      try {
        const categoryResponse = await CategoryServices.getCategory();
        console.log(categoryResponse)
        setCategories(categoryResponse.data.data); // Assuming data structure is correct
        
        const unitResponse = await CategoryServices.getUnit();
        setUnits(unitResponse.data.data);
      } catch (error) {
        console.error('Error fetching categories or units:', error);
      }
    };

    fetchCategoriesAndUnits();
  }, []);

  // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();

    const formData = new FormData();
    for (const key in formValues) {
      formData.append(key, formValues[key]);
    }

    try {
      const response = await ProductServices.AddProduct(formData);
      Swal.fire('Success', 'Master Item added successfully', 'success');
    } catch (error) {
      console.error('Failed to add Master Item:', error);
      Swal.fire('Error', 'Failed to add Master Item', 'error');
    }
  };

  return (
    <>
      <div className="row">
        <div className="col-xl-12">
          <div className="filter cm-content-box box-primary mt-5">
            <div className="content-title">
              <div className="cpa">
                <i className="fas fa-file-word me-2"></i> Add Master Item
              </div>
              <div className="tools">
                <Link
                  to={"#"}
                  className={`SlideToolHeader ${open2 ? "collapse" : "expand"}`}
                  onClick={() => setOpen2(!open2)}
                >
                  <i className="fas fa-angle-up"></i>
                </Link>
              </div>
            </div>

            <Collapse in={open2}>
              <div className="cm-content-body form excerpt">
                <div className="card-body">
                  <form onSubmit={handleSubmit}>
                    <div className="row">
                      <div className="form-group mb-3 col-md-6">
                        <label>Part No.</label>
                        <input
                          type="number"
                          name="partNo"
                          className="form-control"
                          value={formValues.partNo}
                          onChange={handleInputChange}
                          placeholder="Part Number"
                        />
                      </div>

                      <div className="form-group mb-3 col-md-6">
                        <label>Category</label>
                        <select
                          name="category"
                          className="form-select"
                          value={formValues.category}
                          onChange={handleInputChange}
                        >
                          <option value="">Select Category</option>
                          {categories.map((category) => (
                            <option key={category._id} value={category._id}>
                              {category.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="form-group mb-3 col-md-6">
                        <label>Unit</label>
                        <select
                          name="unit"
                          className="form-select"
                          value={formValues.unit}
                          onChange={handleInputChange}
                        >
                          <option value="">Select Unit</option>
                          {units.map((unit) => (
                            <option key={unit._id} value={unit._id}>
                              {unit.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="form-group mb-3 col-md-6">
                        <label>Remark</label>
                        <input
                          type="text"
                          name="remark"
                          className="form-control"
                          value={formValues.remark}
                          onChange={handleInputChange}
                          placeholder="Remark"
                        />
                      </div>

                      <div className="form-group col-md-12">
                        <label>Description</label>
                        <textarea
                          name="description"
                          className="form-control"
                          value={formValues.description}
                          onChange={handleInputChange}
                          placeholder="Description"
                        />
                      </div>

                      <div className="form-group mb-3 col-md-6">
                        <label>Image</label>
                        <div className="input-group">
                          <input
                            type="file"
                            name="photo"
                            className="form-file-input form-control"
                            onChange={handleFileChange}
                          />
                        </div>
                        <div className="file-preview text-center mt-3">
                          <img src={previewImage} alt="Preview" style={{ maxWidth: '200px' }} />
                        </div>
                      </div>
                    </div>

                    <button type="submit" className="btn btn-primary me-2">
                      Add
                    </button>
                    <button type="reset" className="btn btn-danger">
                      Cancel
                    </button>
                  </form>
                </div>
              </div>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default MasterListAdd;
