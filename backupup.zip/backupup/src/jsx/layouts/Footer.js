 import React from "react";

const Footer = () => {
  var d = new Date();
  return (
    <div className="footer">
      <div className="copyright">
      <h4 className="text-center">Copyright © Indigo InfraProjects Pvt. Ltd.</h4>
      </div>
    </div>
  );
};

export default Footer;
