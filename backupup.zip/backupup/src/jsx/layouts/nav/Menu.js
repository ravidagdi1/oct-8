export const MenuList = [
    //Dashboard
    {
        title: 'Dashboard',
        classsChange: 'mm-collapse',
        iconStyle: <i className="flaticon-025-dashboard"></i>,
        content: [
            {
                title: 'Dashboard Light',
                to: 'dashboard',
            },
            
        ],
    },
    //Users
    {
        title: "User",
        classsChange: "mm-collapse",
        //update:"New",
        iconStyle: <i class="fas fa-user"></i>,

        content: [
            {
                title: "User List",
                to: "/user",
            },
            {
                title: "User Inactive List",
                to: "/user-list",
            },
            {
                title: "User Add",
                to: "/user-add",
            },
        ],
    },

    //Location Management
    {
        title: "Location",
        classsChange: 'mm-collapse',
        //update:"New",
        iconStyle:
        <i class="fa-solid fa-location-dot"></i>,
        content: [
            {
                title: 'Location',
                to: '/location'
            },
            {
                title: 'Inactive Location',
                to: '/location-inactive'
            },
            {
                title: 'Add Location',
                to: '/location-add'
            },

        ],
    },

    //Master List

    {
        title: "Master List",
        classsChange: 'mm-collapse',
        //update:"New",
        iconStyle:
        <i class="far fa-newspaper" aria-hidden="true"></i>,
        content: [
            {
                title: 'Master List',
                to: '/master-list'
            },
            {
                title: 'Master Add',
                to: '/master-add'
            },
            {
                title: 'Master Bulk',
                to: '/master-bulk'
            },
            {
                title: 'Master Category',
                to: '/master-cat'
            },
            {
                title: 'Master Unit',
                to: '/master-unit'
            },


        ],
    },

    //inventory

 

     {
        title: "Inventory",
        classsChange: 'mm-collapse',
        //update:"New",
        iconStyle:
        <i class="fa fa-list-ul" aria-hidden="true"></i>,
        content: [
            {
                title: 'Master List',
                to: '/master-list-inv'
            },

            {
                title: 'Inventory List',
                to: '/inventory-list'
            },
            


        ],
    },





    

]